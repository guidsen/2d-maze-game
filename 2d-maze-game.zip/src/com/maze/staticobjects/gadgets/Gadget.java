/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maze.staticobjects.gadgets;

import com.maze.staticobjects.StaticObject;

/**
 *
 * @author Guido
 */
public abstract class Gadget extends StaticObject {

    public void use() {
        // do nothing
    }
}
